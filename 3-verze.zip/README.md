# Algorithms II

[https://www.cs.vsb.cz/dvorsky/Algorithms_II.html]

Implementation of project 1.

## Try it out

To try out this program.
There are examples prepared.

But first build the project by simply calling a Makefile.
(using more cores)
```
make -j 5
```

There's also the file `./treeees.html`
that you can open in the browser
and look at the found MSTs.

### Examples

Just call an anchor in the Makefile.

Here are all the example anchors:
```
make 3
make 3k
make 3a

make 4
make 4k
make 4a

make 5
make 5k
make 5a

make 6
make 6k
make 6a

make 8
make 8k
make 8a

make 9
make 9k
make 9a

make 10
make 10k
make 10a

make 15
make 15k
make 15a

make 20
make 20k
make 20a

make 30
make 30k
make 30a
```
